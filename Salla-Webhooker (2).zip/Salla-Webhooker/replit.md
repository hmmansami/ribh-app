# Ribh - Abandoned Cart Recovery System

## Overview

Ribh is an abandoned cart recovery application for Salla e-commerce stores. It receives webhook events from Salla, tracks abandoned carts, and sends AI-generated WhatsApp recovery messages via Twilio. The system includes a dashboard for monitoring cart recovery performance, scheduling follow-up messages, and testing WhatsApp notifications.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state with 5-second polling for real-time webhook updates
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style)
- **Build Tool**: Vite with custom plugins for Replit integration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Pattern**: RESTful endpoints defined in `shared/routes.ts` with Zod validation
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` contains all table definitions

### Data Models
Four primary tables:
1. `webhookEvents` - Stores raw Salla webhook payloads
2. `abandonedCarts` - Tracks cart details, customer info, and recovery status
3. `recoveryLogs` - Records all recovery message attempts
4. `followUpMessages` - Schedules future follow-up communications

### Key Design Decisions
- **Shared Code**: The `shared/` directory contains schemas and route definitions used by both client and server
- **Type Safety**: Drizzle-Zod generates Zod schemas from database tables for end-to-end type validation
- **Storage Pattern**: `server/storage.ts` provides a DatabaseStorage class implementing an IStorage interface for data access abstraction

### Replit Integrations
Located in `server/replit_integrations/`:
- **Batch Processing**: Rate-limited LLM batch operations with retry logic
- **Chat**: OpenAI-powered conversation system
- **Image**: AI image generation endpoints

## External Dependencies

### Third-Party Services
- **Twilio**: WhatsApp messaging for cart recovery notifications (requires `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_WHATSAPP_NUMBER`)
- **Salla**: E-commerce platform webhook integration for cart events
- **OpenAI**: AI message generation via Replit AI Integrations (requires `AI_INTEGRATIONS_OPENAI_API_KEY`, `AI_INTEGRATIONS_OPENAI_BASE_URL`)

### Database
- PostgreSQL connection via `DATABASE_URL` environment variable
- Migrations stored in `./migrations` directory
- Use `npm run db:push` to sync schema changes

### Build Configuration
- Development: `npm run dev` runs tsx directly
- Production: `npm run build` uses esbuild with select dependencies bundled for faster cold starts