import { pgTable, text, serial, jsonb, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { relations, sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const webhookEvents = pgTable("webhook_events", {
  id: serial("id").primaryKey(),
  eventType: text("event_type").notNull(),
  payload: jsonb("payload").notNull(),
  headers: jsonb("headers"),
  processed: boolean("processed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const abandonedCarts = pgTable("abandoned_carts", {
  id: serial("id").primaryKey(),
  cartId: text("cart_id").notNull().unique(),
  customerName: text("customer_name"),
  customerPhone: text("customer_phone").notNull(),
  items: jsonb("items").notNull(), // Array of products
  totalAmount: text("total_amount"),
  currency: text("currency").default("SAR"),
  status: text("status").default("pending"), // pending, message_sent, recovered, failed
  aiMessage: text("ai_message"),
  lastReminderAt: timestamp("last_reminder_at"),
  reminderCount: integer("reminder_count").default(0),
  isTest: boolean("is_test").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const recoveryLogs = pgTable("recovery_logs", {
  id: serial("id").primaryKey(),
  cartId: integer("cart_id").references(() => abandonedCarts.id),
  message: text("message").notNull(),
  status: text("status").notNull(), // sent, failed
  error: text("error"),
  discountCode: text("discount_code"),
  sentAt: timestamp("sent_at").defaultNow(),
});

export const followUpMessages = pgTable("follow_up_messages", {
  id: serial("id").primaryKey(),
  cartId: integer("cart_id").references(() => abandonedCarts.id).notNull(),
  type: text("type").notNull(), // thank_you, new_products, discount_offer
  scheduledFor: timestamp("scheduled_for").notNull(),
  status: text("status").default("scheduled"), // scheduled, sent, cancelled
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const abandonedCartsRelations = relations(abandonedCarts, ({ many }) => ({
  logs: many(recoveryLogs),
  followUps: many(followUpMessages),
}));

export const followUpMessagesRelations = relations(followUpMessages, ({ one }) => ({
  cart: one(abandonedCarts, {
    fields: [followUpMessages.cartId],
    references: [abandonedCarts.id],
  }),
}));

export const insertFollowUpMessageSchema = createInsertSchema(followUpMessages).omit({
  id: true,
  createdAt: true,
});

export type FollowUpMessage = typeof followUpMessages.$inferSelect;
export type InsertFollowUpMessage = z.infer<typeof insertFollowUpMessageSchema>;

export const recoveryLogsRelations = relations(recoveryLogs, ({ one }) => ({
  cart: one(abandonedCarts, {
    fields: [recoveryLogs.cartId],
    references: [abandonedCarts.id],
  }),
}));

export const insertWebhookEventSchema = createInsertSchema(webhookEvents).omit({
  id: true,
  createdAt: true,
});

export const insertAbandonedCartSchema = createInsertSchema(abandonedCarts).omit({
  id: true,
  createdAt: true,
});

export const insertRecoveryLogSchema = createInsertSchema(recoveryLogs).omit({
  id: true,
  sentAt: true,
});

export type WebhookEvent = typeof webhookEvents.$inferSelect;
export type AbandonedCart = typeof abandonedCarts.$inferSelect;
export type RecoveryLog = typeof recoveryLogs.$inferSelect;

export * from "./models/chat";
