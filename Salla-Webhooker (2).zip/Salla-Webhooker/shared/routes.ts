import { z } from "zod";
import { webhookEvents, abandonedCarts, recoveryLogs } from "./schema";

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  webhooks: {
    list: {
      method: "GET" as const,
      path: "/api/webhooks",
      responses: {
        200: z.array(z.custom<typeof webhookEvents.$inferSelect>()),
      },
    },
    receive: {
      method: "POST" as const,
      path: "/api/webhooks/salla",
      input: z.any(),
      responses: {
        200: z.object({ success: z.boolean(), message: z.string() }),
      },
    },
    validate: {
      method: "GET" as const,
      path: "/api/webhooks/salla",
      responses: {
        200: z.object({ success: z.boolean() }),
      },
    },
  },
  whatsapp: {
    send: {
      method: "POST" as const,
      path: "/api/send-whatsapp",
      input: z.object({
        to: z.string(),
        message: z.string(),
      }),
      responses: {
        200: z.object({ success: z.boolean(), sid: z.string().optional(), error: z.string().optional() }),
      },
    },
  },
  recovery: {
    stats: {
      method: "GET" as const,
      path: "/api/recovery/stats",
      responses: {
        200: z.object({
          sent: z.number(),
          recovered: z.number(),
          pending: z.number(),
        }),
      },
    },
    list: {
      method: "GET" as const,
      path: "/api/recovery/carts",
      responses: {
        200: z.array(z.custom<typeof abandonedCarts.$inferSelect & { logs: (typeof recoveryLogs.$inferSelect)[] }>()),
      },
    },
    trigger: {
      method: "POST" as const,
      path: "/api/recovery/trigger/:id",
      responses: {
        200: z.object({ success: z.boolean(), message: z.string(), aiMessage: z.string().optional() }),
      },
    },
    generateTest: {
      method: "POST" as const,
      path: "/api/recovery/generate-test",
      responses: {
        200: z.custom<typeof abandonedCarts.$inferSelect>(),
      },
    },
    markRecovered: {
      method: "POST" as const,
      path: "/api/recovery/mark-recovered/:id",
      responses: {
        200: z.object({ success: z.boolean() }),
      },
    },
  },
  followUp: {
    schedule: {
      method: "POST" as const,
      path: "/api/follow-up/schedule",
      input: z.object({
        cartId: z.number(),
        type: z.enum(["thank_you", "new_products", "discount_offer"]),
        days: z.number(),
      }),
      responses: {
        200: z.custom<typeof abandonedCarts.$inferSelect>(),
      },
    },
    list: {
      method: "GET" as const,
      path: "/api/follow-up/list",
      responses: {
        200: z.array(z.any()), // Simplified for speed
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
