import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { type WebhookEvent } from "@shared/schema";

export function useWebhooks() {
  return useQuery({
    queryKey: [api.webhooks.list.path],
    queryFn: async () => {
      const res = await fetch(api.webhooks.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch webhooks");
      const data = await res.json();
      return api.webhooks.list.responses[200].parse(data);
    },
    // Poll every 5 seconds to see new incoming webhooks
    refetchInterval: 5000,
  });
}
