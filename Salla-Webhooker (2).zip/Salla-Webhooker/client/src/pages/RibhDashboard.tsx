import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  MessageCircle,
  Send,
  Sparkles,
  TrendingUp,
  X,
  ChevronDown,
  Zap,
  CheckCircle,
  Clock,
  AlertTriangle,
  ChevronUp,
} from "lucide-react";

export default function RibhDashboard() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [isActive, setIsActive] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState("");
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [messages, setMessages] = useState<
    { role: "user" | "ai"; text: string }[]
  >([
    { role: "ai", text: "مرحباً! أنا هنا لمساعدتك. اسألني أي سؤال عن رِبح!" },
  ]);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const { data: stats } = useQuery<{
    sent: number;
    recovered: number;
    pending: number;
  }>({
    queryKey: ["/api/recovery/stats"],
  });

  const { data: carts } = useQuery<any[]>({
    queryKey: ["/api/recovery/carts"],
  });

  const recoveredCarts = carts?.filter((c) => c.status === "recovered") || [];
  const totalRevenue = recoveredCarts.reduce(
    (sum, cart) => sum + (parseFloat(cart.totalAmount) || 0),
    0,
  );
  const recoveryRate =
    stats && stats.sent > 0
      ? Math.round((stats.recovered / stats.sent) * 100)
      : 0;
  const inProgress =
    carts?.filter((c) => c.status === "message_sent").length || 0;

  const generateTestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/recovery/generate-test");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/carts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/stats"] });
    },
  });

  const FAQ_ITEMS = [
    {
      q: "كيف يعمل رِبح؟",
      a: "عند ترك عميل لسلته، يرسل رِبح تلقائياً رسالة واتساب ذكية تحفزه على إكمال الشراء. كل شي تلقائي!",
    },
    {
      q: "هل أحتاج أسوي أي شي؟",
      a: "لا! فقط فعّل التطبيق واتركه يعمل. رِبح يعمل 24/7 بالخلفية بدون أي تدخل منك.",
    },
    {
      q: "كم نسبة النجاح المتوقعة؟",
      a: "متوسط استعادة السلات المتروكة 15-25%. يعني لو عندك 100 سلة متروكة، ممكن تستعيد 15-25 منها!",
    },
    {
      q: "هل بيانات عملائي آمنة؟",
      a: "نعم 100%. نستخدم تشفير متقدم ولا نشارك بيانات عملائك مع أي طرف ثالث.",
    },
    {
      q: "كم تكلفة الاشتراك؟",
      a: "فترة تجريبية مجانية، ثم اشتراك شهري بسيط. العائد أضعاف التكلفة!",
    },
  ];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleChat = () => {
    if (!chatInput.trim()) return;
    const userMsg = chatInput;
    setMessages((prev) => [...prev, { role: "user", text: userMsg }]);
    setChatInput("");

    setTimeout(() => {
      let response =
        "شكراً على سؤالك! رِبح يعمل تلقائياً لاستعادة السلات المتروكة. هل تحتاج مساعدة بشي ثاني؟";
      setMessages((prev) => [...prev, { role: "ai", text: response }]);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex flex-col" dir="rtl">
      {/* WELCOME POPUP */}
      {showWelcome && (
        <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#111] border border-white/10 rounded-3xl max-w-lg w-full p-8 relative">
            <button
              onClick={() => setShowWelcome(false)}
              className="absolute top-4 left-4 text-gray-500 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Pain Point */}
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <AlertTriangle className="w-8 h-8 text-red-400" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">
                هل تعلم؟ 🤔
              </h2>
              <p className="text-gray-400 text-lg">
                <span className="text-red-400 font-bold text-3xl">70%</span> من
                العملاء يتركون سلاتهم بدون إكمال الشراء
              </p>
            </div>

            {/* Data Points */}
            <div className="bg-white/5 rounded-2xl p-4 mb-6">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <p className="text-3xl font-bold text-amber-400">٧ من ١٠</p>
                  <p className="text-xs text-gray-500">عملاء يتركون السلة</p>
                </div>
                <div>
                  <p className="text-3xl font-bold text-red-400">٠ ريال</p>
                  <p className="text-xs text-gray-500">
                    إيراداتك من السلات المتروكة حالياً
                  </p>
                </div>
              </div>
            </div>

            {/* Dream Outcome */}
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-emerald-400" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">
                مع رِبح، استعد أموالك! 💰
              </h3>
              <p className="text-gray-400">
                رِبح يحوّل السلات المتروكة إلى مبيعات حقيقية{" "}
                <span className="text-emerald-400 font-bold">تلقائياً</span>
              </p>
            </div>

            {/* How it works - Super Simple */}
            <div className="flex items-center justify-center gap-2 text-sm text-gray-500 mb-6">
              <span className="bg-white/10 px-3 py-1 rounded-full">
                سلة متروكة
              </span>
              <span>←</span>
              <span className="bg-white/10 px-3 py-1 rounded-full">
                رسالة ذكية
              </span>
              <span>←</span>
              <span className="bg-emerald-500/20 text-emerald-400 px-3 py-1 rounded-full">
                ربح!
              </span>
            </div>

            {/* CTA */}
            <Button
              onClick={() => setShowWelcome(false)}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-lg py-6 rounded-xl"
            >
              ابدأ الآن - مجاناً ✨
            </Button>

            <p className="text-center text-xs text-gray-600 mt-3">
              بدون بطاقة ائتمان • إلغاء في أي وقت
            </p>
          </div>
        </div>
      )}

      {/* HEADER */}
      <header className="border-b border-white/5 bg-[#0a0a0a]/90 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-2xl mx-auto px-6 py-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold text-white">رِبح</span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-400">
              {isActive ? "نشط" : "متوقف"}
            </span>
            <Switch checked={isActive} onCheckedChange={setIsActive} />
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="flex-1 max-w-2xl mx-auto px-6 py-10 w-full">
        {/* Revenue Card */}
        <Card className="bg-emerald-600 border-0 mb-8">
          <CardContent className="p-8 text-center text-white">
            <p className="text-emerald-100 text-sm mb-2">أرباحك الإضافية</p>
            <div className="mb-2">
              <span className="text-5xl font-bold">
                {totalRevenue.toLocaleString()}
              </span>
              <span className="text-xl text-emerald-100 mr-2">ريال</span>
            </div>
            <p className="text-emerald-200 text-sm flex items-center justify-center gap-2">
              <Zap className="w-4 h-4" />
              رِبح يعمل تلقائياً
            </p>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="bg-white/5 border-white/5">
            <CardContent className="p-4 text-center">
              <CheckCircle className="w-5 h-5 text-emerald-400 mx-auto mb-2" />
              <p className="text-xl font-bold text-white">
                {stats?.recovered || 0}
              </p>
              <p className="text-xs text-gray-500">مُستعاد</p>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/5">
            <CardContent className="p-4 text-center">
              <Clock className="w-5 h-5 text-amber-400 mx-auto mb-2" />
              <p className="text-xl font-bold text-white">{inProgress}</p>
              <p className="text-xs text-gray-500">قيد المتابعة</p>
            </CardContent>
          </Card>
          <Card className="bg-white/5 border-white/5">
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-5 h-5 text-blue-400 mx-auto mb-2" />
              <p className="text-xl font-bold text-white">{recoveryRate}%</p>
              <p className="text-xs text-gray-500">نسبة النجاح</p>
            </CardContent>
          </Card>
        </div>

        {/* Activity */}
        <Card className="bg-white/5 border-white/5 mb-8">
          <CardContent className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-medium flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                النشاط
              </h3>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-400"
                onClick={() => generateTestMutation.mutate()}
              >
                🧪 تجربة
              </Button>
            </div>

            <div className="space-y-2">
              {carts?.slice(0, 5).map((cart: any) => (
                <div
                  key={cart.id}
                  className="flex items-center justify-between p-3 bg-white/5 rounded-xl"
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        cart.status === "recovered"
                          ? "bg-emerald-400"
                          : cart.status === "message_sent"
                            ? "bg-blue-400"
                            : "bg-amber-400"
                      }`}
                    />
                    <span className="text-sm text-white">
                      {cart.customerName}
                    </span>
                    <span className="text-xs text-gray-500">
                      {cart.totalAmount} ر.س
                    </span>
                  </div>
                  <span
                    className={`text-xs ${
                      cart.status === "recovered"
                        ? "text-emerald-400"
                        : cart.status === "message_sent"
                          ? "text-blue-400"
                          : "text-amber-400"
                    }`}
                  >
                    {cart.status === "recovered" && "✓ تم"}
                    {cart.status === "message_sent" && "↻ متابعة"}
                    {cart.status === "pending" && "⏳ جديد"}
                  </span>
                </div>
              ))}
              {(!carts || carts.length === 0) && (
                <p className="text-center text-gray-600 py-6">
                  ينتظر أول سلة...
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </main>

      {/* FAQ FOOTER */}
      <footer className="border-t border-white/5 bg-[#0a0a0a] mt-auto">
        <div className="max-w-2xl mx-auto px-6 py-8">
          <h3 className="text-white font-medium mb-4 text-center">
            الأسئلة الشائعة
          </h3>

          <div className="space-y-2">
            {FAQ_ITEMS.map((faq, i) => (
              <div
                key={i}
                className="border border-white/5 rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full p-4 text-right flex items-center justify-between text-white hover:bg-white/5"
                >
                  <span className="text-sm">{faq.q}</span>
                  {openFaq === i ? (
                    <ChevronUp className="w-4 h-4 text-gray-500" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-gray-500" />
                  )}
                </button>
                {openFaq === i && (
                  <div className="px-4 pb-4 text-sm text-gray-400">{faq.a}</div>
                )}
              </div>
            ))}
          </div>

          <p className="text-center text-gray-600 text-xs mt-6">
            © 2024 رِبح - جميع الحقوق محفوظة
          </p>
        </div>
      </footer>

      {/* CHAT */}
      <div className="fixed bottom-6 left-6 z-50">
        {chatOpen && (
          <Card className="w-72 mb-4 shadow-2xl bg-[#1a1a1a] border-white/10">
            <div className="bg-emerald-600 p-3 flex items-center justify-between text-white">
              <span className="font-medium text-sm">مساعد رِبح</span>
              <button onClick={() => setChatOpen(false)}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="h-48 overflow-y-auto p-3 space-y-2 bg-[#0f0f0f]">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-start" : "justify-end"}`}
                >
                  <div
                    className={`max-w-[85%] p-2 rounded-xl text-xs ${
                      msg.role === "user"
                        ? "bg-white/10 text-white"
                        : "bg-emerald-600 text-white"
                    }`}
                  >
                    {msg.text}
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>
            <div className="p-2 border-t border-white/10 flex gap-2">
              <Input
                placeholder="اكتب..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleChat()}
                className="flex-1 bg-white/5 border-white/10 text-white text-xs h-8"
              />
              <Button
                size="icon"
                className="bg-emerald-600 h-8 w-8"
                onClick={handleChat}
              >
                <Send className="w-3 h-3" />
              </Button>
            </div>
          </Card>
        )}
        <Button
          className="w-12 h-12 rounded-full bg-emerald-600 shadow-lg"
          onClick={() => setChatOpen(!chatOpen)}
        >
          <MessageCircle className="w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
