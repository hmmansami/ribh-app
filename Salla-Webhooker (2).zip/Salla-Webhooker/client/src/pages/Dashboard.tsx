import { useWebhooks } from "@/hooks/use-webhooks";
import { WebhookDetails } from "@/components/WebhookDetails";
import { StatusBadge } from "@/components/StatusBadge";
import { useState } from "react";
import { format } from "date-fns";
import { WebhookEvent, AbandonedCart } from "@shared/schema";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Inbox, Activity, Clock, ArrowRight, ShoppingCart, Send, CheckCircle, RefreshCcw, TestTube, Calendar, Gift, Heart } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";

export default function Dashboard() {
  const { data: webhooks, isLoading: isLoadingWebhooks } = useWebhooks();
  const { toast } = useToast();
  
  const { data: carts, isLoading: isLoadingCarts } = useQuery<(AbandonedCart & { logs: any[] })[]>({
    queryKey: ["/api/recovery/carts"],
  });

  const { data: stats, isLoading: isLoadingStats } = useQuery<{ sent: number; recovered: number; pending: number }>({
    queryKey: ["/api/recovery/stats"],
  });

  const { data: followUps, isLoading: isLoadingFollowUps } = useQuery<any[]>({
    queryKey: ["/api/follow-up/list"],
  });

  const generateTestMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/recovery/generate-test");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/carts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/stats"] });
      toast({ title: "Test Cart Generated", description: "A new mock abandoned cart has been added." });
    },
  });

  const triggerRecoveryMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/recovery/trigger/${id}`);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/carts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/stats"] });
      toast({ 
        title: "Recovery Message Sent (Simulated)", 
        description: data.aiMessage,
        className: "bg-emerald-50 border-emerald-200"
      });
    },
  });

  const markRecoveredMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("POST", `/api/recovery/mark-recovered/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/carts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/recovery/stats"] });
      toast({ title: "Cart Recovered", description: "Status updated to recovered." });
    },
  });

  const scheduleFollowUpMutation = useMutation({
    mutationFn: async ({ cartId, type, days }: { cartId: number, type: string, days: number }) => {
      await apiRequest("POST", "/api/follow-up/schedule", { cartId, type, days });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/follow-up/list"] });
      toast({ title: "Follow-up Scheduled", description: "Your message has been queued." });
    },
  });

  const [selectedWebhook, setSelectedWebhook] = useState<WebhookEvent | null>(null);
  const [search, setSearch] = useState("");

  const isLoading = isLoadingWebhooks || isLoadingCarts || isLoadingStats || isLoadingFollowUps;

  return (
    <div className="min-h-screen bg-muted/30 pb-20 rtl" dir="rtl">
      {/* Header Area */}
      <div className="bg-background border-b border-border/60 sticky top-0 z-10 backdrop-blur-xl bg-background/80">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-200">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold tracking-tight text-foreground">لوحة تحكم رِبـح (RIBH)</h1>
                <p className="text-sm text-muted-foreground hidden sm:block">نظام استعادة السلال المتروكة الذكي</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
               <Button 
                 onClick={() => generateTestMutation.mutate()} 
                 disabled={generateTestMutation.isPending}
                 className="bg-emerald-600 hover:bg-emerald-700 text-white gap-2"
               >
                 <TestTube className="w-4 h-4" />
                 توليد سلة تجريبية
               </Button>
               <div className="relative w-full md:w-64">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input 
                  placeholder="بحث..." 
                  className="pr-9 bg-muted/50 border-transparent focus:bg-background transition-all"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        <Tabs defaultValue="carts" className="w-full">
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-8">
            <TabsTrigger value="carts">السلال المتروكة</TabsTrigger>
            <TabsTrigger value="followups">المتابعة التسويقية</TabsTrigger>
          </TabsList>

          <TabsContent value="carts">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-8 mb-8">
              <Card className="border-border/60 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الرسائل المرسلة</CardTitle>
                  <Send className="w-4 h-4 text-emerald-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.sent || 0}</div>
                </CardContent>
              </Card>

              <Card className="border-border/60 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">السلال المستعادة</CardTitle>
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.recovered || 0}</div>
                </CardContent>
              </Card>

              <Card className="border-border/60 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">معدل الاستعادة</CardTitle>
                  <RefreshCcw className="w-4 h-4 text-blue-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {stats && (stats.sent > 0) ? Math.round((stats.recovered / stats.sent) * 100) : 0}%
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Carts Table */}
            <Card className="border-border/60 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-emerald-600" />
                  السلال المتروكة
                </CardTitle>
              </CardHeader>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">العميل</TableHead>
                    <TableHead className="text-right">المبلغ</TableHead>
                    <TableHead className="text-right">الحالة</TableHead>
                    <TableHead className="text-right">آخر رسالة</TableHead>
                    <TableHead className="text-left">الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {carts?.map((cart) => (
                    <TableRow key={cart.id}>
                      <TableCell>
                        <div className="font-medium">{cart.customerName}</div>
                        <div className="text-xs text-muted-foreground">{cart.customerPhone}</div>
                      </TableCell>
                      <TableCell>{cart.totalAmount} {cart.currency}</TableCell>
                      <TableCell>
                        <Badge variant={cart.status === "recovered" ? "default" : "secondary"}>
                          {cart.status === "pending" && "قيد الانتظار"}
                          {cart.status === "message_sent" && "تم إرسال رسالة"}
                          {cart.status === "recovered" && "تمت الاستعادة"}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate text-xs text-muted-foreground">
                        {cart.aiMessage || "لم يتم الإرسال"}
                      </TableCell>
                      <TableCell className="text-left space-x-2 space-x-reverse">
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => triggerRecoveryMutation.mutate(cart.id)}
                          disabled={triggerRecoveryMutation.isPending || cart.status === "recovered"}
                        >
                          إرسال تذكير
                        </Button>
                        {cart.status === "recovered" ? (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="sm" variant="secondary" className="gap-2">
                                <Calendar className="w-4 h-4" />
                                جدولة متابعة
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-56">
                              <DropdownMenuLabel>نوع الرسالة</DropdownMenuLabel>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => scheduleFollowUpMutation.mutate({ cartId: cart.id, type: "thank_you", days: 7 })}>
                                <Heart className="w-4 h-4 ml-2" /> شكر (7 أيام)
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => scheduleFollowUpMutation.mutate({ cartId: cart.id, type: "new_products", days: 14 })}>
                                <ShoppingCart className="w-4 h-4 ml-2" /> منتجات جديدة (14 يوم)
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => scheduleFollowUpMutation.mutate({ cartId: cart.id, type: "discount_offer", days: 30 })}>
                                <Gift className="w-4 h-4 ml-2" /> عرض خاص (30 يوم)
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        ) : (
                          <Button 
                            size="sm" 
                            className="bg-emerald-600 hover:bg-emerald-700"
                            onClick={() => markRecoveredMutation.mutate(cart.id)}
                            disabled={markRecoveredMutation.isPending}
                          >
                            تمت الاستعادة
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="followups">
            <Card className="border-border/60 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-emerald-600" />
                  المتابعات المجدولة
                </CardTitle>
              </CardHeader>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">العميل</TableHead>
                    <TableHead className="text-right">النوع</TableHead>
                    <TableHead className="text-right">موعد الإرسال</TableHead>
                    <TableHead className="text-right">الحالة</TableHead>
                    <TableHead className="text-right">الرسالة</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {followUps?.map((fu) => (
                    <TableRow key={fu.id}>
                      <TableCell>عميل #{fu.cartId}</TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {fu.type === "thank_you" && "شكر"}
                          {fu.type === "new_products" && "منتجات جديدة"}
                          {fu.type === "discount_offer" && "عرض خاص"}
                        </Badge>
                      </TableCell>
                      <TableCell>{format(new Date(fu.scheduledFor), "PP")}</TableCell>
                      <TableCell>
                        <Badge variant={fu.status === "sent" ? "default" : "secondary"}>
                          {fu.status === "scheduled" && "مجدولة"}
                          {fu.status === "sent" && "تم الإرسال"}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-[300px] truncate text-xs text-muted-foreground">
                        {fu.message}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
