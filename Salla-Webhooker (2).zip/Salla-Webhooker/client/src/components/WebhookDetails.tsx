import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { WebhookEvent } from "@shared/schema";
import { format } from "date-fns";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Copy, Check } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface WebhookDetailsProps {
  webhook: WebhookEvent | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WebhookDetails({ webhook, open, onOpenChange }: WebhookDetailsProps) {
  const [copied, setCopied] = useState<string | null>(null);

  if (!webhook) return null;

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[85vh] flex flex-col p-0 gap-0 overflow-hidden bg-background/95 backdrop-blur-xl border-border/50 shadow-2xl">
        <DialogHeader className="p-6 border-b border-border/50 bg-muted/20">
          <div className="flex items-center gap-3 mb-2">
            <Badge variant="outline" className="font-mono text-xs uppercase tracking-wider bg-background/50">
              ID: {webhook.id}
            </Badge>
            <Badge 
              variant="secondary" 
              className="bg-primary/10 text-primary border-primary/20 hover:bg-primary/20 transition-colors"
            >
              {webhook.eventType}
            </Badge>
          </div>
          <DialogTitle className="text-2xl">Webhook Details</DialogTitle>
          <DialogDescription className="text-muted-foreground flex items-center gap-2">
            Received on {format(new Date(webhook.createdAt || new Date()), "PPP 'at' pp")}
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-1 p-6">
          <div className="space-y-8">
            {/* Headers Section */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Headers</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 text-xs gap-1.5"
                  onClick={() => copyToClipboard(JSON.stringify(webhook.headers, null, 2), 'headers')}
                >
                  {copied === 'headers' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied === 'headers' ? "Copied" : "Copy JSON"}
                </Button>
              </div>
              <div className="rounded-xl border border-border/50 bg-slate-950 shadow-inner overflow-hidden group relative">
                <div className="absolute top-3 right-3 flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700/50" />
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700/50" />
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-700/50" />
                </div>
                <pre className="p-4 text-xs md:text-sm font-mono text-slate-300 overflow-x-auto selection:bg-primary/30">
                  {JSON.stringify(webhook.headers, null, 2)}
                </pre>
              </div>
            </div>

            {/* Payload Section */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Payload</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-8 text-xs gap-1.5"
                  onClick={() => copyToClipboard(JSON.stringify(webhook.payload, null, 2), 'payload')}
                >
                  {copied === 'payload' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied === 'payload' ? "Copied" : "Copy JSON"}
                </Button>
              </div>
              <div className="rounded-xl border border-border/50 bg-slate-950 shadow-inner overflow-hidden relative">
                <div className="absolute top-3 right-3 flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/20" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/20" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500/20" />
                </div>
                <pre className="p-4 text-xs md:text-sm font-mono text-blue-300 overflow-x-auto selection:bg-primary/30">
                  {JSON.stringify(webhook.payload, null, 2)}
                </pre>
              </div>
            </div>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
