import { cn } from "@/lib/utils";

interface StatusBadgeProps {
  status: boolean; // processed or not
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border transition-colors",
        status 
          ? "bg-green-50 text-green-700 border-green-200" 
          : "bg-amber-50 text-amber-700 border-amber-200",
        className
      )}
    >
      <span className={cn(
        "w-1.5 h-1.5 rounded-full mr-1.5",
        status ? "bg-green-500" : "bg-amber-500"
      )} />
      {status ? "Processed" : "Pending"}
    </span>
  );
}
