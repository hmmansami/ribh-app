## Packages
date-fns | Date formatting for timestamps
clsx | Utility for constructing className strings
tailwind-merge | Utility for merging Tailwind classes safely
lucide-react | Icons for the UI (already in base stack but good to note)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Outfit", "sans-serif"],
  mono: ["JetBrains Mono", "monospace"],
}
