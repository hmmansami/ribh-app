import { db } from "./db";
import { webhookEvents, abandonedCarts, recoveryLogs, followUpMessages, type InsertWebhookEvent, type WebhookEvent, type AbandonedCart, type RecoveryLog, type FollowUpMessage } from "@shared/schema";
import { desc, eq, sql } from "drizzle-orm";

export interface IStorage {
  createWebhookEvent(event: InsertWebhookEvent): Promise<WebhookEvent>;
  getWebhookEvents(): Promise<WebhookEvent[]>;
  
  // Abandoned Carts
  upsertAbandonedCart(cart: any): Promise<AbandonedCart>;
  getAbandonedCarts(): Promise<(AbandonedCart & { logs: RecoveryLog[] })[]>;
  getAbandonedCart(id: number): Promise<AbandonedCart | undefined>;
  updateAbandonedCart(id: number, updates: Partial<AbandonedCart>): Promise<AbandonedCart>;
  
  // Recovery Logs
  createRecoveryLog(log: any): Promise<RecoveryLog>;
  getRecoveryStats(): Promise<{ sent: number; recovered: number; pending: number }>;
  
  // Follow Up
  scheduleFollowUp(followUp: any): Promise<FollowUpMessage>;
  getFollowUps(): Promise<FollowUpMessage[]>;
}

export class DatabaseStorage implements IStorage {
  async createWebhookEvent(event: InsertWebhookEvent): Promise<WebhookEvent> {
    const [webhook] = await db.insert(webhookEvents).values(event).returning();
    return webhook;
  }

  async getWebhookEvents(): Promise<WebhookEvent[]> {
    return await db.select().from(webhookEvents).orderBy(desc(webhookEvents.createdAt));
  }

  async upsertAbandonedCart(cart: any): Promise<AbandonedCart> {
    const [existing] = await db.select().from(abandonedCarts).where(eq(abandonedCarts.cartId, cart.cartId));
    if (existing) {
      const [updated] = await db.update(abandonedCarts).set(cart).where(eq(abandonedCarts.cartId, cart.cartId)).returning();
      return updated;
    }
    const [inserted] = await db.insert(abandonedCarts).values(cart).returning();
    return inserted;
  }

  async getAbandonedCarts(): Promise<(AbandonedCart & { logs: RecoveryLog[] })[]> {
    const carts = await db.select().from(abandonedCarts).orderBy(desc(abandonedCarts.createdAt));
    const results = [];
    for (const cart of carts) {
      const logs = await db.select().from(recoveryLogs).where(eq(recoveryLogs.cartId, cart.id)).orderBy(desc(recoveryLogs.sentAt));
      results.push({ ...cart, logs });
    }
    return results;
  }

  async getAbandonedCart(id: number): Promise<AbandonedCart | undefined> {
    const [cart] = await db.select().from(abandonedCarts).where(eq(abandonedCarts.id, id));
    return cart;
  }

  async updateAbandonedCart(id: number, updates: Partial<AbandonedCart>): Promise<AbandonedCart> {
    const [updated] = await db.update(abandonedCarts).set(updates).where(eq(abandonedCarts.id, id)).returning();
    return updated;
  }

  async createRecoveryLog(log: any): Promise<RecoveryLog> {
    const [inserted] = await db.insert(recoveryLogs).values(log).returning();
    return inserted;
  }

  async getRecoveryStats(): Promise<{ sent: number; recovered: number; pending: number }> {
    const logs = await db.select({ count: sql<number>`count(*)` }).from(recoveryLogs);
    const recovered = await db.select({ count: sql<number>`count(*)` }).from(abandonedCarts).where(eq(abandonedCarts.status, 'recovered'));
    const pending = await db.select({ count: sql<number>`count(*)` }).from(abandonedCarts).where(eq(abandonedCarts.status, 'pending'));
    
    return {
      sent: Number(logs[0]?.count || 0),
      recovered: Number(recovered[0]?.count || 0),
      pending: Number(pending[0]?.count || 0),
    };
  }

  async scheduleFollowUp(followUp: any): Promise<FollowUpMessage> {
    const [inserted] = await db.insert(followUpMessages).values(followUp).returning();
    return inserted;
  }

  async getFollowUps(): Promise<FollowUpMessage[]> {
    return await db.select().from(followUpMessages).orderBy(desc(followUpMessages.scheduledFor));
  }
}

export const storage = new DatabaseStorage();
