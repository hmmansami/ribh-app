import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import twilio from "twilio";

const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // GET handler for Salla URL validation
  app.get(api.webhooks.receive.path, (req, res) => {
    res.status(200).json({ success: true, message: "Webhook ready", app: "ribh" });
  });

  // Test WhatsApp Endpoint
  app.post("/api/test-whatsapp", async (req, res) => {
    const { phone, message } = req.body;
    if (!phone || !message) {
      return res.status(400).json({ error: "Phone and message are required" });
    }

    try {
      const result = await twilioClient.messages.create({
        from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
        to: `whatsapp:${phone}`,
        body: message
      });
      res.json({ success: true, sid: result.sid });
    } catch (error: any) {
      console.error("Twilio Test Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Salla Webhook Receiver
  app.post(api.webhooks.receive.path, async (req, res) => {
    try {
      // Salla typically sends the event name in a header or body.
      // We'll try to extract it, or default to 'unknown'
      const eventType = req.body.event || req.headers['x-salla-event'] || 'unknown';
      
      const webhookData = {
        eventType: String(eventType),
        payload: req.body,
        headers: req.headers as Record<string, any>,
        processed: false
      };

      await storage.createWebhookEvent(webhookData);

      // Always return 200 OK to acknowledge receipt to Salla
      res.json({ success: true, message: "Webhook received" });
    } catch (error) {
      console.error("Error processing webhook:", error);
      // Still return 200 to avoid Salla retrying if it's our processing logic failing
      // unless we want them to retry. Usually for logging we accept everything.
      res.status(200).json({ success: false, message: "Error logging webhook" });
    }
  });

  // GET handler for Salla URL validation
  app.get(api.webhooks.receive.path, (req, res) => {
    res.status(200).json({ success: true, message: "Webhook ready", app: "ribh" });
  });
  // List Webhooks
  app.get(api.webhooks.list.path, async (req, res) => {
    const events = await storage.getWebhookEvents();
    res.json(events);
  });

  // Salla Webhook Receiver (GET for validation)
  app.get(api.webhooks.validate.path, (req, res) => {
    res.json({ success: true });
  });

  // Recovery Stats
  app.get(api.recovery.stats.path, async (req, res) => {
    const stats = await storage.getRecoveryStats();
    res.json(stats);
  });

  // Recovery Carts List
  app.get(api.recovery.list.path, async (req, res) => {
    const carts = await storage.getAbandonedCarts();
    res.json(carts);
  });

  // Generate Test Cart
  app.post(api.recovery.generateTest.path, async (req, res) => {
    const names = ["أحمد محمد", "سارة خالد", "عبدالله علي", "نورة فهد", "فهد سليمان"];
    const products = [
      { id: 1, name: "ثوب قطني أبيض", price: 250 },
      { id: 2, name: "شماغ أحمر كلاسيك", price: 180 },
      { id: 3, name: "عباية سوداء مطرزة", price: 450 },
      { id: 4, name: "عطر عود ملكي", price: 320 },
    ];
    
    const randomName = names[Math.floor(Math.random() * names.length)];
    const randomProduct = products[Math.floor(Math.random() * products.length)];
    const randomPhone = `+9665${Math.floor(10000000 + Math.random() * 90000000)}`;
    
    const cart = await storage.upsertAbandonedCart({
      cartId: `TEST-${Date.now()}`,
      customerName: randomName,
      customerPhone: randomPhone,
      items: [randomProduct],
      totalAmount: String(randomProduct.price),
      currency: "SAR",
      status: "pending",
      isTest: true
    });
    
    res.json(cart);
  });

  // Trigger Recovery Message
  app.post(api.recovery.trigger.path, async (req, res) => {
    const id = Number(req.params.id);
    const cart = await storage.getAbandonedCart(id);
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    const customerName = cart.customerName || "عميلنا العزيز";
    const cartValue = cart.totalAmount || "0";
    const aiMessage = `مرحباً ${customerName}! لاحظنا إنك تركت سلة مشترياتك. عندك ${cartValue} ريال في الانتظار! أكمل طلبك الآن واستمتع بخصم 10% 🛒`;

    let twilioStatus = "sent";
    let twilioError = null;

    try {
      await twilioClient.messages.create({
        from: `whatsapp:${process.env.TWILIO_WHATSAPP_NUMBER}`,
        to: `whatsapp:${cart.customerPhone}`,
        body: aiMessage
      });
    } catch (error: any) {
      console.error("Twilio Error:", error);
      twilioStatus = "failed";
      twilioError = error.message;
    }

    await storage.updateAbandonedCart(id, {
      status: twilioStatus === "sent" ? "message_sent" : "failed",
      aiMessage,
      reminderCount: (cart.reminderCount || 0) + 1,
      lastReminderAt: new Date()
    });

    await storage.createRecoveryLog({
      cartId: id,
      message: aiMessage,
      status: twilioStatus,
      error: twilioError
    });

    res.json({ 
      success: twilioStatus !== "failed", 
      message: twilioStatus === "sent" ? "WhatsApp message sent" : "Mock message generated", 
      aiMessage 
    });
  });

  // Mark as Recovered
  app.post(api.recovery.markRecovered.path, async (req, res) => {
    const id = Number(req.params.id);
    await storage.updateAbandonedCart(id, { status: "recovered" });
    res.json({ success: true });
  });

  // Schedule Follow Up
  app.post(api.followUp.schedule.path, async (req, res) => {
    const { cartId, type, days } = api.followUp.schedule.input.parse(req.body);
    const cart = await storage.getAbandonedCart(cartId);
    if (!cart) return res.status(404).json({ message: "Cart not found" });

    const scheduledFor = new Date();
    scheduledFor.setDate(scheduledFor.getDate() + days);

    const templates: Record<string, string> = {
      thank_you: "شكراً لتسوقك معنا يا {name}! نحن سعداء باختيارك لمنتجاتنا.",
      new_products: "أهلاً {name}، لقد وصلت تشكيلة جديدة من المنتجات التي قد تعجبك!",
      discount_offer: "عرض خاص يا {name}! استخدم كود SPECIAL15 للحصول على خصم 15% على طلبك التالي."
    };

    const message = templates[type].replace("{name}", cart.customerName || "عميلنا");

    const followUp = await storage.scheduleFollowUp({
      cartId,
      type,
      scheduledFor,
      message,
      status: "scheduled"
    });

    res.json(followUp);
  });

  app.get(api.followUp.list.path, async (req, res) => {
    const followUps = await storage.getFollowUps();
    res.json(followUps);
  });

  return httpServer;
}
